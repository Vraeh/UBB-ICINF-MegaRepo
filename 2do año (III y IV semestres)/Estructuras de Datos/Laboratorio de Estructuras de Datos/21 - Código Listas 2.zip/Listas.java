public class Listas {
    Nodo inicio;

    public Listas(){
        inicio=null;
    }

    public void insertarInicio(int x){
        Nodo nuevo = new Nodo(x);
        if(inicio==null){
            inicio = nuevo;
        }
        else{
            nuevo.sig = inicio;
            inicio = nuevo;
        }
    }

    public void insertarFinal(int x){
        Nodo nuevo = new Nodo(x);

        if(inicio==null){
            inicio = nuevo;
        }
        else{
            Nodo aux =inicio;
            while(aux.sig!=null){
                aux = aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public boolean encontrar(int x){
        Nodo aux =inicio;
        while(aux!=null){
            if(aux.dato==x){
                return true;
            }
            aux=aux.sig;
        }
        return false;
    }

    public void eliminar(int x){
        if(inicio.dato ==x){
            inicio = inicio.sig;
        }
        else{
            Nodo anterior = inicio;
            Nodo aux = inicio.sig;
            while(aux!=null){
                if(aux.dato==x){
                    anterior.sig=aux.sig;
                    aux = aux.sig;
                }
                else{
                    anterior=anterior.sig;
                    aux=aux.sig;
                }
            }
        }
    }

    void insertarAntes(int x, int antesDe){

        if(inicio.dato==antesDe) {
            insertarInicio(x);
        }
        else{
            Nodo aux = inicio.sig;
            Nodo anterior = inicio;
            while(aux!=null){
                if(aux.dato==antesDe){
                    Nodo nuevo = new Nodo(x);
                    anterior.sig=nuevo;
                    nuevo.sig = aux;
                    anterior=aux;
                    aux = aux.sig;
                }
                else {
                    aux = aux.sig;
                    anterior=anterior.sig;
                }
            }
        }

    }

    void insertarDespues(int x, int despuesDe){
        Nodo nuevo = new Nodo(x);
        Nodo aux = inicio;
        while(aux!=null){
            if(aux.dato==despuesDe){
                nuevo.sig = aux.sig;
                aux.sig = nuevo;
                break;
            }
            else{
                aux = aux.sig;
            }
        }
    }

    void intercambiar(int a,int b){
        Nodo aux = inicio;
        while(aux!=null){
            if(aux.dato==a){
                aux.dato=b;
            }
            aux=aux.sig;
        }
    }

    float promedio(){
        float promedio=0;
        int cont=0;
        Nodo aux = inicio;
        while(aux!=null){
            cont++;
            promedio+=aux.dato;
            aux=aux.sig;
        }
        return promedio/cont;
    }
    void listaMayoresProm(){
        Nodo aux = inicio;
        float promedio = promedio();

        while(aux!=null){
            if(aux.dato<=promedio){
                eliminar(aux.dato);
            }
            aux=aux.sig;
        }
    }
    @Override
    public String toString(){
        String salida ="";
        Nodo aux = inicio;

        while(aux!=null){
            salida = salida + aux.toString();
            aux = aux.sig;
        }

        return salida;
    }
}
