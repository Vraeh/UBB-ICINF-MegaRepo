public class Listas {
    Nodo inicio;

    public Listas(){
        inicio=null;
    }

    public void insertarInicio(int x){
        Nodo nuevo = new Nodo(x);
        if(inicio==null){
            inicio = nuevo;
        }
        else{
            nuevo.sig = inicio;
            inicio = nuevo;
        }
    }

    public void insertarFinal(int x){
        Nodo nuevo = new Nodo(x);

        if(inicio==null){
            inicio = nuevo;
        }
        else{
            Nodo aux = inicio;
            while(aux.sig!=null){
                aux=aux.sig;
            }
            aux.sig = nuevo;
        }
    }

    public boolean encontrar(int x){
        Nodo aux =inicio;
        while(aux!=null){
            if(aux.dato==x){
                return true;
            }
            aux=aux.sig;
        }
        return false;
    }

    public void eliminar(int x){
        if(inicio.dato ==x){
            inicio = inicio.sig;
        }
        else{
            Nodo anterior = inicio;
            Nodo aux = inicio.sig;
            while(aux!=null){
                if(aux.dato==x){
                    anterior.sig=aux.sig;
                    aux = aux.sig;
                }
                else{
                    anterior=anterior.sig;
                    aux=aux.sig;
                }
            }
        }
    }

    @Override
    public String toString(){
        String salida ="";
        Nodo aux = inicio;

        while(aux!=null){
            salida = salida + aux.toString();
            aux = aux.sig;
        }

        return salida;
    }
}
