
public class test2 {
    public static void main(String[] args) {

        PilaDinamica p = new PilaDinamica();
        p.pushOrdenado(3);
        p.pushOrdenado(6);
        p.pushOrdenado(7);
        p.pushOrdenado(4);
        p.pushOrdenado(5);
        p.pushOrdenado(1);
        p.pushOrdenado(2);
        p.pushOrdenado(0);
        p.pushOrdenado(-1);
        System.out.println("Pila = " + p);

        ColaDinamica c = new ColaDinamica();
        c.push(3);
        c.push(4);
        c.push(1);
        c.push(2);
        c.push(6);
        c.push(5);
        System.out.println("c original = " + c);
        c.sort();
        System.out.println("c ordenado = " + c);


        ColaDinamica c2 = new ColaDinamica();
        c2.push(1);
        c2.push(7);
        c2.push(5);
        c2.push(3);
        c2.push(2);
        c2.push(4);
        c2.push(6);
        System.out.println("c2 original = " + c2);
        c2.eliminarPrimos();
        System.out.println("c2 con primos eliminados = " + c2);
    }
}
