public class Nodo {
    int elemento;
    Nodo sig;

    public Nodo(int elemento){
        this.elemento = elemento;
        sig = null;
    }

    @Override
    public String toString(){
        return elemento+"-->";
    }
}
