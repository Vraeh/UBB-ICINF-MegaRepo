public class PilaDinamica {
    Nodo tope;

    public PilaDinamica(){
        tope=null;
    }

    public boolean isEmpty(){
        return tope==null;
    }

    public int peek(){
        if(!isEmpty()){
            return tope.elemento;
        }
        return -1;
    }

    public void push(int elemento){
        Nodo nuevo = new Nodo(elemento);
        if(isEmpty()){
            tope=nuevo;
        }
        else{
            nuevo.sig = tope;
            tope = nuevo;
        }
    }

    public void pop(){
        if(!isEmpty()){
            tope = tope.sig;
        }
    }

    public  void pushOrdenado(int n) {
        //INGRESE SU CÓDIGO AQUÍ
    }

    @Override
    public String toString(){
        PilaDinamica p = new PilaDinamica();
        String salida = "";
        while(!this.isEmpty()){
            salida+=this.peek()+"-->";
            p.push(this.peek());
            this.pop();
        }

        while(!p.isEmpty()){
            this.push(p.peek());
            p.pop();
        }

        return salida;
    }
}
