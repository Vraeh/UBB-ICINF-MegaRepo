import java.util.ArrayList;

public class ABB {
    private Nodo raiz;

    public ABB(){
        raiz=null;
    }

    public void insertar(int elemento){
        raiz = insertar(elemento,raiz);
    }

    private Nodo insertar(int elemento,Nodo n){
        //NODO NULL
        if(n==null){
            Nodo nuevo = new Nodo(elemento);
            return nuevo;
        }
        else{
            //MENOR
            if(n.valor>elemento){
                n.izq = insertar(elemento,n.izq);
            }
            else{
                //MAYOR
                if(n.valor<elemento){
                    n.der = insertar(elemento,n.der);
                }
            }
            //IGUAL
            return n;
        }
    }

    public boolean encontrar(int elemento){
        return encontrar(elemento,raiz);
    }

    private boolean encontrar(int elemento,Nodo n){
        //NULL
        if(n==null){
            return false;
        }
        else{
            //MENOR
            if(n.valor>elemento){
                return encontrar(elemento,n.izq);
            }
            else{
                //MAYOR
                if(n.valor<elemento){
                    return encontrar(elemento,n.der);
                }
                //IGUAL
                else{
                    return true;
                }
            }
        }
    }

    public void eliminar(int elemento){
        raiz = eliminar(elemento,raiz);
    }

    //Sin hijos
    //Solo un hijo
    //Dos hijos
    //No existe
    private Nodo eliminar(int elemento,Nodo n){
        //No existe
        if(n==null){
            return null;
        }
        else{
            if(n.valor>elemento){
                n.izq = eliminar(elemento,n.izq);
            }
            else{
                if(n.valor<elemento){
                    n.der = eliminar(elemento,n.der);
                }
                else{
                    //Sin hijos
                    if(n.izq==null && n.der==null){
                        n = null;
                    }
                    else{
                        if(n.izq!=null&&n.der!=null){
                            Nodo aux = maximo(n.izq);
                            n.valor = aux.valor;
                            n.izq = eliminar(aux.valor,n.izq);
                        }
                        else{
                            if(n.izq!=null){
                                n = n.izq;
                            }
                            else{
                                n = n.der;
                            }
                        }
                    }
                }
            }
        }
        return n;
    }

    private Nodo minimo(Nodo n){
        if(n.izq==null){
            return n;
        }
        else{
            return minimo(n.izq);
        }
    }



    private Nodo maximo(Nodo n){
        if(n.der==null){
            return n;
        }
        else{
            return maximo(n.der);
        }
    }

    public void preOrder(){
        if(raiz!=null){
            preOrder(raiz);
            System.out.println("");
        }
        else{
            System.out.println("Arbol vacio");
        }
    }

    private void preOrder(Nodo n){
        if(n!=null){
            System.out.print(n.valor+" ");
            preOrder(n.izq);
            preOrder(n.der);
        }
    }

    public void inOrder() {
        if (raiz != null) {
            inOrder(raiz);
            System.out.println("");
        } else {
            System.out.println("Arbol vacio");
        }
    }

    private void inOrder(Nodo n){
        if(n!=null){
            inOrder(n.izq);
            System.out.print(n.valor+" ");
            inOrder(n.der);
        }
    }
     public void postOrder(){
        if(raiz!=null){
            postOrder(raiz);
            System.out.println("");
        }
        else{
            System.out.println("Arbol vacio");
        }
     }

     private void postOrder(Nodo n){
        if(n!=null){
            postOrder(n.izq);
            postOrder(n.der);
            System.out.print(n.valor+" ");
        }
     }

     public int contarNodos(){
        if(raiz!=null){
            return contarNodos(raiz);
        }
        return 0;
     }

     private int contarNodos(Nodo n){
        if(n==null) return 0;
        return 1+contarNodos(n.izq)+contarNodos(n.der);
     }

     public int sumar(){
        if(raiz!=null){
            return sumar(raiz);
        }
        return 0;
     }

     private int sumar(Nodo n){
        if(n==null) return 0;
        return n.valor + sumar(n.izq) + sumar(n.der);
     }

     public Integer numMaximo(){
        if(raiz!=null){
            return numMaximo(raiz);
        }
        return null;
     }

     private Integer numMaximo(Nodo n){
        if(n.der==null) return n.valor;
        return numMaximo(n.der);
     }

     public Integer numMinimo(){
        if(raiz!=null){
            return numMinimo(raiz);
        }
        return null;
     }

     private  Integer numMinimo(Nodo n){
        if(n.izq==null) return n.valor;
        return numMinimo(n.izq);
     }

     public Integer costoCamino(int elemento){
        if(raiz!=null && encontrar(elemento)){
            return costoCamino(elemento,raiz);
        }
        return null;
     }
     private Integer costoCamino(int elemento,Nodo n){
        if(n.valor==elemento){
            return n.valor;
        }
        if(n.valor<elemento){
            return n.valor + costoCamino(elemento,n.der);
        }
        return n.valor + costoCamino(elemento,n.izq);
    }
    @Override
    public String toString(){
        String salida = "", salidx = "";
        Nodo bad = new Nodo(-1);
        ArrayList<Nodo> lista = new ArrayList<Nodo>(), listb = new ArrayList<Nodo>();
        int opcion = 1;
        boolean todosmenosuno;
        lista.add(raiz);
        do{
            if(opcion==1){
                for(Nodo n: lista){
                    if(n.valor!=bad.valor){
                        salida += n.valor + " - ";
                        if(n.izq!=null) listb.add(n.izq);
                        else listb.add(bad);
                        if(n.der!=null) listb.add(n.der);
                        else listb.add(bad);
                    }
                    else{
                        salida += "xx - ";
                        listb.add(bad);
                        listb.add(bad);
                    }
                }
                lista.clear();
                todosmenosuno = true;
                for(Nodo n: listb){
                    if(n.valor!=bad.valor){
                        todosmenosuno = false;
                    }
                }
                if(todosmenosuno) listb.clear();
            }
            else{
                for(Nodo n: listb){
                    if(n.valor!=bad.valor){
                        salida += n.valor + " - ";
                        if(n.izq!=null) lista.add(n.izq);
                        else lista.add(bad);
                        if(n.der!=null) lista.add(n.der);
                        else lista.add(bad);
                    }
                    else{
                        salida += "xx - ";
                        lista.add(bad);
                        lista.add(bad);
                    }
                }
                listb.clear();
                todosmenosuno = true;
                for(Nodo n: lista){
                    if(n.valor!=bad.valor){
                        todosmenosuno = false;
                    }
                }
                if(todosmenosuno) lista.clear();
            }
            opcion = opcion*(-1);
            salida += "\n";
        }
        while(!lista.isEmpty()||!listb.isEmpty());
        String[] salidb = salida.split("\n");
        int m = salidb.length;
        for(int i=0;i<m;i++){
            String[] salidc = salidb[i].split(" - ");
            int x = (int)Math.pow(2,(m-1-i))-1;
            int y = (int)Math.pow(2,(m-i))-1;
            for(int z=0;z<x;z++) salidx += "  ";
            for(int j=0;j<salidc.length;j++){
                if(!salidc[j].equals("xx")) if(Integer.parseInt(salidc[j])<10) salidx += "0";
                salidx += salidc[j];
                if(j!=(salidc.length-1)){ for(int z=0;z<y;z++) salidx += "  ";}
            }
            salidx += "\n";
        }
        return salidx;
    }
}
