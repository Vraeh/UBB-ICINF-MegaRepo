public class Nodo {
    int valor;
    Nodo izq;
    Nodo der;

    public Nodo(int valor){
        this.valor=valor;
        izq=null;
        der=null;
    }
}
