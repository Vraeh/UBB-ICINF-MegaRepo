public class Main {
    public static void main(String[] args) {
        int numeros[] = {9,3,2,1,4,8,6,10,5,12};
        ABB arbol = new ABB();
        ABB arbol2 = new ABB();
        for (int i = 0; i < numeros.length; i++) {
            arbol.insertar(numeros[i]);
        }

        System.out.println("arbol = " + arbol);
        arbol.preOrder();
        arbol.inOrder();
        arbol.postOrder();

        System.out.println("arbol.contarNodos() = " + arbol.contarNodos());
        System.out.println("arbol.sumar() = " + arbol.sumar());
        System.out.println("arbol.numMaximo() = " + arbol.numMaximo());
        System.out.println("arbol.numMinimo() = " + arbol.numMinimo());
        System.out.println("arbol.costoCamino(1) = " + arbol.costoCamino(1));
    }
}
