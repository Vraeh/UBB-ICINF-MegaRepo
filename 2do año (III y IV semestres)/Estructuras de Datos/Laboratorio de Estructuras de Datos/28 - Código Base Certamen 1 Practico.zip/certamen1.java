


public class certamen1 {
    public static void main(String [] args){
        Lista list = new Lista();
        list.insertarInicio(10);
        System.out.println(list.toString());
        list.insertarInicio(11);
        System.out.println(list.toString());
        list.insertarInicio(12);
        System.out.println(list.toString());

        list.insertarFinal(13);
        System.out.println(list.toString());
        list.insertarFinal(14);
        System.out.println(list.toString());
        list.insertarFinal(15);
        System.out.println(list.toString());
        if(list.encontrar(15)){
            System.out.println("Se encontro el numero");
        }
        else{
            System.out.println("No se encontro el numero");
        }

        list.eliminar(13);
        list.insertarFinal(15);
        System.out.println(list.toString());
        list.insertarAntes(13,15);
        System.out.println(list.toString());

        //CERTAMEN
        list.intercambiarNodos(1,2);
        System.out.println(list.toString());

        list.insertarMedio(9);
        System.out.println(list.toString());


        list.eliminarDuplicados();
        System.out.println(list.toString());


    }


}