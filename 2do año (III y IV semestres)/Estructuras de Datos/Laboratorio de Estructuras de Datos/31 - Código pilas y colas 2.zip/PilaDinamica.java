public class PilaDinamica {
    Nodo tope;

    public PilaDinamica(){
        tope=null;
    }

    public boolean isEmpty(){
      return tope==null;
    }

    public int peek(){
        if(!isEmpty()){
            return tope.elemento;
        }
        return -1;
    }

    public void push(int elemento){
        Nodo nuevo = new Nodo(elemento);
        if(isEmpty()){
            tope=nuevo;
        }
        else{
            nuevo.sig = tope;
            tope = nuevo;
        }
    }

    public void pop(){
        if(!isEmpty()){
            tope = tope.sig;
        }
    }

    public PilaDinamica copy(){
        PilaDinamica p = new PilaDinamica();
        PilaDinamica p2 = new PilaDinamica();
        while(!this.isEmpty()){
            p.push(this.peek());
            this.pop();
        }

        while(!p.isEmpty()){
            p2.push(p.peek());
            p.pop();
        }
        return p2;
    }

    public void pushOrdenado(int x){
        if (isEmpty()){
            push(x);
        }
        else{
            PilaDinamica aux = new PilaDinamica();
            while(!isEmpty()){
                if(peek()<x){
                    break;
                }
                else{
                    aux.push(peek());
                    pop();
                }
            }
            push(x);
            while (!aux.isEmpty()){
                push(aux.peek());
                aux.pop();
            }
        }
    }



    public void invertir(){
        PilaDinamica aux1 = new PilaDinamica();
        PilaDinamica aux2 = new PilaDinamica();

        while(!isEmpty()){
            aux1.push(peek());
            pop();
        }

        while(!aux1.isEmpty()){
            aux2.push(aux1.peek());
            aux1.pop();
        }

        while(!aux2.isEmpty()){
            push(aux2.peek());
            aux2.pop();
        }
    }

    @Override
    public String toString(){
        PilaDinamica p = new PilaDinamica();
        String salida = "";
        while(!this.isEmpty()){
            salida+=this.peek()+"-->";
            p.push(this.peek());
            this.pop();
        }

        while(!p.isEmpty()){
            this.push(p.peek());
            p.pop();
        }

        return salida;
    }
}
