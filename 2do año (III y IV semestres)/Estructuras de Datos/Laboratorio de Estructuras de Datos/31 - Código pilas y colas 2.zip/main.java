public class main {

    public static void main(String[] args) {
        PilaDinamica p = new PilaDinamica();
        ColaDinamica c = new ColaDinamica();
        System.out.println("---------------Inicio Insercion Pila---------------\n");
        p.pushOrdenado(3);
        System.out.println("Se inserta 3: Pila queda: "+p);
        p.pushOrdenado(6);
        System.out.println("Se inserta 6: Pila queda: "+p);
        p.pushOrdenado(7);
        System.out.println("Se inserta 7: Pila queda: "+p);
        p.pushOrdenado(4);
        System.out.println("Se inserta 4: Pila queda: "+p);
        p.pushOrdenado(5);
        System.out.println("Se inserta 5: Pila queda: "+p);
        p.pushOrdenado(1);
        System.out.println("Se inserta 1: Pila queda: "+p);
        p.pushOrdenado(2);
        System.out.println("Se inserta 2: Pila queda: "+p);
        System.out.println("\n----------------Fin Insercion Pila----------------\n");
        p.invertir();
        System.out.println("Se invirtio la pila, Pila queda: "+p);
        System.out.println("\n----------------Inicio Insercion Cola----------------\n");
        c.push(6);
        System.out.println("Se inserta 6: Cola queda: "+c);
        c.push(5);
        System.out.println("Se inserta 5: Cola queda: "+c);
        c.push(4);
        System.out.println("Se inserta 4: Cola queda: "+c);
        c.push(3);
        System.out.println("Se inserta 3: Cola queda: "+c);
        c.push(2);
        System.out.println("Se inserta 2: Cola queda: "+c);
        c.push(1);
        System.out.println("Se inserta 1: Cola queda: "+c);
        System.out.println("\n----------------Fin Insercion Cola----------------\n");
        c.reemplazar(5,8);
        System.out.println("Se reemplaza elementos 5 por elementos 8, Cola queda: "+c);
        c.mantenerPares();
        System.out.println("Se mantuvieron solo pares, Cola queda: "+c);
        c.invertir();
        System.out.println("Cola Invertida:" + c);
    }
}
