/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author HP
 */
public class Certamen2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        ABB arbol = new ABB();
        int[] datos = {6,3,4,2,9,8,10,11,12};
        for(int i=0;i<datos.length;i++){
            arbol.insertar(datos[i]);
        }
        System.out.println("arbol = " + arbol);
        System.out.println("arbol.cuentaPrimos(3) = " + arbol.cuentaPrimos(3));
        System.out.println("arbol.cuentaPrimos(2) = " + arbol.cuentaPrimos(2));
        System.out.println("arbol.cuentaPrimos(11) = " + arbol.cuentaPrimos(0));
        System.out.println("arbol.cuentaPrimos(5) = " + arbol.cuentaPrimos(5));

        System.out.println("arbol.numDecendientes(3) = " + arbol.numDecendientes(3));
        System.out.println("arbol.numDecendientes(9) = " + arbol.numDecendientes(9));
        System.out.println("arbol.numDecendientes(5) = " + arbol.numDecendientes(5));

        System.out.println("arbol.encontrarMenor(1) = " + arbol.encontrarMenor(1));
        System.out.println("arbol.encontrarMenor(2) = " + arbol.encontrarMenor(2));
        System.out.println("arbol.encontrarMenor(3) = " + arbol.encontrarMenor(3));
    }
    
}
