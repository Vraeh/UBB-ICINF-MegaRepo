/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

import java.util.ArrayList;

/**
 *
 * @author HP
 */
public class ABB {
    Nodo raiz;

    public ABB(){
        raiz = null;
    }

    public void insertar(int elemento){
          raiz = insertar(elemento,raiz);
    }

    private Nodo insertar(int elemento,Nodo n){
        //NULL
        if(n==null){
            return new Nodo(elemento);
        }
        else{
            //elemento < nodo.dato
            if(elemento<n.dato){
                n.izq = insertar(elemento,n.izq);
            }
            else{
                //elemento> nodo.dato
                if(elemento>n.dato){
                    n.der = insertar(elemento, n.der);
                }
            }
            return n ;
        }
    }

    public boolean encontrar(int elemento){
        return encontrar(elemento,raiz);
    }

    private boolean encontrar(int elemento,Nodo n){
        if(n==null){
            return  false;
        }
        else{
            if(n.dato==elemento){
                return true;
            }
            if(elemento<n.dato){
                return encontrar(elemento,n.izq);
            }
            return encontrar(elemento,n.der);
        }
    }

    public void eliminar(int elemento){
        raiz = eliminar(elemento,raiz); // le paso la sumatoria iniciada en 0;
    }

    private Nodo eliminar(int elemento,Nodo n){
        if(n!=null){
            if(elemento<n.dato){
                n.izq = eliminar(elemento,n.izq);
            }else{
                if(elemento>n.dato){
                    n.der = eliminar(elemento,n.der);
                }
                else{
                    if(n.izq==null && n.der==null){
                        n=null;
                    }
                    else{
                        if(n.der==null){
                            n=n.izq;
                        }
                        else{
                            if(n.izq==null){
                                n=n.der;
                            }
                            else{
                                Nodo temp=minimo(n.der);
                                n.dato = temp.dato;
                                n.der = eliminar(temp.dato,n.der);
                            }
                        }
                    }
                }
            }
        }
        return n;
    }

    private Nodo minimo(Nodo n){
        if(n.izq==null){
            return n;
        }
        else{
            return minimo(n.izq);
        }
    }

    public  void preOrden(){
        if(raiz==null){
            System.out.println("Arbol vacio");
        }
        else{
            preOrden(raiz);
            System.out.println("");
        }
    }

    private void preOrden(Nodo n){
        System.out.print(n.dato+ " ");
        if(n.izq!=null){
            preOrden(n.izq);
        }
        if(n.der!=null){
            preOrden(n.der);
        }
    }

    public  void inOrden(){
        if(raiz==null){
            System.out.println("Arbol vacio");
        }
        else{
            inOrden(raiz);
            System.out.println("");
        }
    }

    private void inOrden(Nodo n){
        if(n.izq!=null){
            inOrden(n.izq);
        }
        System.out.print(n.dato+ " ");
        if(n.der!=null){
            inOrden(n.der);
        }
    }

    public  void postOrden(){
        if(raiz==null){
            System.out.print("Arbol vacio");
        }
        else{
            postOrden(raiz);
            System.out.println("");
        }
    }

    private void postOrden(Nodo n){
        if(n.izq!=null){
            postOrden(n.izq);
        }
        if(n.der!=null){
            postOrden(n.der);
        }
        System.out.print(n.dato+ " ");
    }

    public int cuentaPrimos(int elemento){

    }

    public int numDecendientes(int elemento){

    }

    public int encontrarMenor(int k){

    }

    
    @Override
    public String toString(){
        String salida = "", salidx = "";
        Nodo bad = new Nodo(-1);
        ArrayList<Nodo> lista = new ArrayList<Nodo>(), listb = new ArrayList<Nodo>();
        int opcion = 1;
        boolean todosmenosuno;
        lista.add(raiz);
        do{
            if(opcion==1){
                for(Nodo n: lista){
                    if(n.dato!=bad.dato){
                        salida += n.dato + " - ";
                        if(n.izq!=null) listb.add(n.izq);
                        else listb.add(bad);
                        if(n.der!=null) listb.add(n.der);
                        else listb.add(bad);
                    }
                    else{
                        salida += "xx - ";
                        listb.add(bad);
                        listb.add(bad);
                    }
                }
                lista.clear();
                todosmenosuno = true;
                for(Nodo n: listb){
                    if(n.dato!=bad.dato){
                        todosmenosuno = false;
                    }
                }
                if(todosmenosuno) listb.clear();
            }
            else{
                for(Nodo n: listb){
                    if(n.dato!=bad.dato){
                        salida += n.dato + " - ";
                        if(n.izq!=null) lista.add(n.izq);
                        else lista.add(bad);
                        if(n.der!=null) lista.add(n.der);
                        else lista.add(bad);
                    }
                    else{
                        salida += "xx - ";
                        lista.add(bad);
                        lista.add(bad);
                    }
                }
                listb.clear();
                todosmenosuno = true;
                for(Nodo n: lista){
                    if(n.dato!=bad.dato){
                        todosmenosuno = false;
                    }
                }
                if(todosmenosuno) lista.clear();
            }
            opcion = opcion*(-1);
            salida += "\n";
        }
        while(!lista.isEmpty()||!listb.isEmpty());
        String[] salidb = salida.split("\n");
        int m = salidb.length;
        for(int i=0;i<m;i++){
            String[] salidc = salidb[i].split(" - ");
            int x = (int)Math.pow(2,(m-1-i))-1;
            int y = (int)Math.pow(2,(m-i))-1;
            for(int z=0;z<x;z++) salidx += "  ";
            for(int j=0;j<salidc.length;j++){
                if(!salidc[j].equals("xx")) if(Integer.parseInt(salidc[j])<10) salidx += "0";
                salidx += salidc[j];
                if(j!=(salidc.length-1)){ for(int z=0;z<y;z++) salidx += "  ";}
            }
            salidx += "\n";
        }
        return salidx;
    }
}
