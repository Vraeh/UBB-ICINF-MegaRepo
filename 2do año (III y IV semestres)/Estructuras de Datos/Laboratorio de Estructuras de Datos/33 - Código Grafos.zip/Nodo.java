public class Nodo {
    int valor;
    Adyacente inicio;
    Nodo(int valor){
        this.valor=valor;
        inicio=null;
    }
    @Override
    public String toString(){
        String salida="";

        salida+="Nodo: "+valor;
        Adyacente aux = inicio;
        while(aux!=null){
            salida+="\n"+valor+"-->"+aux.destino;
            aux=aux.siguiente;
        }
        salida+="\n";
        return  salida;
    }
}
