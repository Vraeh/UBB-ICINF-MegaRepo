public class Main {
    public static void main(String[] args) {
        Grafo g1 = new Grafo(4);
        g1.insertar(0,1);
        g1.insertar(0,3);
        g1.insertar(1,2);
        g1.insertar(2,3);
        g1.insertar(3,1);
        g1.insertar(0,1);
        System.out.println("g1 = " + g1);
        Grafo g2 = g1.productoGrafos(g1);
        System.out.println("g2 = " + g2);
        Grafo g3 = g2.productoGrafos(g2);
        System.out.println("g3 = " + g3);
    }
}
