public class Grafo {
    Nodo vertices[];

    public Grafo(int n){
        vertices = new Nodo[n];
        for (int i = 0; i < n; i++) {
            vertices[i] = new Nodo(i);
        }
    }

    public void insertar(int origen,int destino){
        if(origen<0 || origen> vertices.length-1){
            System.out.println("El origen no es valido");
        }
        else{
            Adyacente nuevo = new Adyacente(destino);
            if(vertices[origen].inicio==null){
                vertices[origen].inicio=nuevo;
            }
            else{
                Adyacente aux = vertices[origen].inicio;
                while(aux.siguiente!=null && aux.destino!=destino){
                    aux = aux.siguiente;
                }
                if (aux.siguiente==null){
                    aux.siguiente= nuevo;
                }
            }
        }
    }

    public Grafo productoGrafos(Grafo g2){
        if(vertices.length != g2.vertices.length){
            System.out.println("Grafos no compatibles");
            return null;
        }
        else{
            Grafo prod = new Grafo(vertices.length);
            for (int i = 0; i < vertices.length; i++) {
                Adyacente aux = vertices[i].inicio;
                while(aux!=null){
                    Adyacente aux2 = g2.vertices[aux.destino].inicio;
                    while(aux2!=null){
                        prod.insertar(vertices[i].valor,aux2.destino);
                        aux2=aux2.siguiente;
                    }
                    aux=aux.siguiente;
                }
            }
            return prod;
        }
    }
    @Override
    public String toString(){
        String salida="Grafo:\n";
        for (int i = 0; i < vertices.length; i++) {
            salida+=vertices[i].toString();
        }
        return salida;
    }
}
