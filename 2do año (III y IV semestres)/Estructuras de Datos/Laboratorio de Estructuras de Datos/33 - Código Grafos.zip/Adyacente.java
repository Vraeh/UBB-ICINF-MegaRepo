public class Adyacente {
    int destino;
    Adyacente siguiente;
    Adyacente(int destino){
        this.destino = destino;
        siguiente=null;
    }
}