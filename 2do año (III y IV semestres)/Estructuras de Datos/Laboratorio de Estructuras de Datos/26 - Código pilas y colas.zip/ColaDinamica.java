public class ColaDinamica {
    Nodo inicio;
    Nodo fin;

    public ColaDinamica(){
        inicio = null;
        fin = null;
    }
    public boolean isEmpty(){
        return inicio==null;
    }

    public int peek(){
        if(!isEmpty()){
            return inicio.elemento;
        }
        return -1;
    }

    public void push(int elemento){
        Nodo nuevo = new Nodo(elemento);
        if(isEmpty()){
            inicio=nuevo;
            fin=nuevo;
        }
        else{
            fin.sig = nuevo;
            fin = nuevo;
        }
    }

    public void pop(){
        if(!isEmpty()){
            inicio = inicio.sig;
        }
    }

    public ColaDinamica copy(){
        ColaDinamica p = new ColaDinamica();
        while(!this.isEmpty()){
            p.push(this.peek());
            this.pop();
        }

        return p;
    }

    @Override
    public String toString(){
        ColaDinamica p = new ColaDinamica();
        String salida = "";
        while(!this.isEmpty()){
            salida+=this.peek()+"-->";
            p.push(this.peek());
            this.pop();
        }

        while(!p.isEmpty()){
            this.push(p.peek());
            p.pop();
        }

        return salida;
    }
}
