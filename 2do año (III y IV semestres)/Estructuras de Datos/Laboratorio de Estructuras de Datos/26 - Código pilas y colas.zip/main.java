public class main {

    public static void main(String[] args) {
        PilaDinamica p1 = new PilaDinamica();
        ColaDinamica c1 = new ColaDinamica();
        p1.pushOrdenado(1);
        p1.pushOrdenado(2);
        p1.pushOrdenado(6);
        p1.pushOrdenado(4);
        p1.pushOrdenado(9);

        c1.push(1);
        c1.push(2);
        c1.push(3);
        c1.push(4);
        c1.push(5);
        System.out.println("Pila Dinamica: "+p1);

        System.out.println("Cola Dinamica: "+c1);

        p1.invertir();
        ColaDinamica c2 = c1.copy();

        System.out.println("Pila Dinamica 2: "+p1);

        System.out.println("Cola Dinamica 2: "+c2);
    }
}
