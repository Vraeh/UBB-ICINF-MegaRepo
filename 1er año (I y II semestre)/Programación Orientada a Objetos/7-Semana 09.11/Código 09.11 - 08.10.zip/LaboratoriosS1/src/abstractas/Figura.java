/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractas;

/**
 *
 * @author Jazna
 */
public abstract class Figura implements ICaclculable{
    private String color;

    public Figura(String color) {
        this.color = color;
    }

    public Figura() {
        this.color = "SIN COLOR";
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    @Override
    public String toString() {
        return super.toString(); //To change body of generated methods, choose Tools | Templates.
    }
    
    public boolean equals(Figura f){
        return true;
    }
}
