/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorioss1;

import java.util.Scanner;

/**
 *
 * @author Jazna
 */
public class LaboratoriosS1 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // Crear un objeto de la clase Colaborador
        Colaborador cx = new Colaborador();
        /* Cambia el estado del objeto desde su estado inicial (valores por defecto) */
        cx.setRut("12345120-1");
        cx.setNombre("Pedro");
        cx.setSueldo(1600000);
        /* Imprimir el estado del objeto (corresponde al valor de sus atributo) */
        String rut  = cx.getRut();
        String nombre  = cx.getNombre();
        int sueldo = cx.getSueldo();
        System.out.println("Rut : " + rut);
        System.out.println("Nombre : " + nombre);
        System.out.println("Sueldo : " + sueldo);
        
        /* Crear un objeto leyendo los valores para sus atributos desde teclado */
        Scanner teclado = new Scanner(System.in);
        /* Leer valores desde teclado */
        System.out.print("Ingrese rut : ");
        String x_rut = teclado.nextLine();
        System.out.print("Ingrese nombre : ");
        String x_nombre = teclado.nextLine();
        System.out.print("Ingrese sueldo : ");
        int x_sueldo = teclado.nextInt();
        /* Crear el objeto usando el constructor CON PARAMETROS */
        Colaborador cy = new Colaborador(x_rut, x_nombre, x_sueldo);
        
        /* Imprimir el esatdo del objeto */

        System.out.println("Rut =  " + cy.getRut());
        System.out.println("Nombre =  " + cy.getNombre());
        System.out.println("Sueldo =  " + cy.getSueldo());
        System.out.println("Sueldo + bono =  " + (cy.getSueldo() + cy.calcularBono()));
        
    }
    
}
