/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asociacion;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class Empresa {
    private String nombre;
    private final ArrayList<Colaborador> colaboradores = new ArrayList();

    public Empresa(String nombre) {
        this.setNombre(nombre);
    }
    
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        if (nombre.length() >= 10){
            this.nombre = nombre;
        }
    }
    
    /* Agrega un colaborador a la lista de claboradores */
    public void contratar(Colaborador c){
        this.colaboradores.add(c);
    }

    public ArrayList<Colaborador> getColaboradores() {
        return colaboradores;
    }
    
    /* Métodos especialziados */
    public int obtenerTotalColaboradores(){
        return this.colaboradores.size(); 
    }
    
    public int obtenerPromedioSueldo(){
        /* Obtener el total de colaboradores */
        int total = this.obtenerTotalColaboradores();
        int suma = 0;
        /* Sumar el sueldo de todos los colaboradores */
        for(Colaborador c : this.colaboradores){
            suma += c.getSueldo();
            /*
            La instrucción anterior es un resumen de la instrucción más tradicional: 
            suma = suma + c.getSueldo();
            */
        }
        return suma/total;
    }
    
    public byte obtenerEdadColaboradorMasJoven(){
      byte edadMasJoven = this.colaboradores.get(0).getEdad();
      for(Colaborador c : this.colaboradores){
          if (c.getEdad() < edadMasJoven){
              edadMasJoven = c.getEdad();
          }
      }  
      return edadMasJoven;
    }
}
