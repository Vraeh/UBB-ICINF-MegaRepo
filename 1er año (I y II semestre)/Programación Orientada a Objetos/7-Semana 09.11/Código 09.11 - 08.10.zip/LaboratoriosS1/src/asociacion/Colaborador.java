/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asociacion;

/**
 *
 * @author Jazna
 */
public class Colaborador {
    private String nombre;
    private int sueldo;
    private byte edad;
    
    private Empresa empresa;
    
    public Colaborador(String nombre, int sueldo, byte edad, Empresa empresa){
        this.empresa = empresa;
        this.setNombre(nombre);
        this.setEdad(edad);
        this.setSueldo(sueldo);
    }

    public Empresa getEmpresa() {
        return empresa;
    }

    public void setEmpresa(Empresa empresa) {
        this.empresa = empresa;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) {
        this.sueldo = sueldo;
    }

    public byte getEdad() {
        return edad;
    }

    public void setEdad(byte edad) {
        this.edad = edad;
    }
    
}
