/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package asociacion;

import java.util.Scanner;

/**
 *
 * @author Jazna
 */
public class MainLabAsociacion {
    public static void main(String[] args) {
        /* Crea un objeto de la clase de Empresa */
        Empresa e;
        Scanner teclado = new Scanner(System.in);
        System.out.print("Ingrese nombre : ");
        String nombre = teclado.nextLine();
        e = new Empresa(nombre);
        //e = new Empresa("Colun");
        /* Crear 3 objtetos de tipo colaborador */
        Colaborador a,b,c;
        a = new Colaborador("Wuacoldo", 450000, (byte) 45, e);
        b = new Colaborador("Petronila", 650000, (byte) 36, e);
        c = new Colaborador("Dexter", 750000, (byte) 63, e);
        
        /* Asociar los colaboradores a la empresa */
        e.contratar(c);
        e.contratar(b);
        e.contratar(a);
        
        /* Imprimir usando los métodos especializados */
        System.out.println("Total de colaboradores : " + e.obtenerTotalColaboradores());
        System.out.println("Promedio sueldos : " + e.obtenerPromedioSueldo());
        System.out.println("Edad más joven : " + e.obtenerEdadColaboradorMasJoven());
        
        System.out.println("Nombre de la empresa : " + e.getNombre());
        
    }
}
