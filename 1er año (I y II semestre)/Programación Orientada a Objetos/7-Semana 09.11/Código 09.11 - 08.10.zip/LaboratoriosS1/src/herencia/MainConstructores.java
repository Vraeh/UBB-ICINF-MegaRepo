/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author Jazna
 */
public class MainConstructores {
    public static void main(String[] args) {
        Circulo c;
        c = new Circulo(29.6f, "nuestro circulo");
        
        /* Imprimir el estado del objeto usando los métodos GETTER */
        System.out.println("Nombre : " + c.getNombre());
        System.out.println("Color  : " + c.getColor());
        System.out.println("Radio  : " + c.getRadio());
        
        /* Ya revisamos que las líneas anteriores, funcionalmente, se pueden 
            reemplazar por la siguiente
        */
        System.out.println("Datos círculo" + c);
        
        /* Podemos asignar un color al círculo */
        c.setColor("azul");
        c.setNombre("círculo azul");
        /* Imprimir el nuevo estado del círculo */
        System.out.println("Nuevo estado " + c);
    }
}
