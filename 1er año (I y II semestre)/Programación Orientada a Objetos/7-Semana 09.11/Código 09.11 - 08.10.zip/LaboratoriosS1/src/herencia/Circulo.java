/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author Jazna
 */
public class Circulo extends Figura {

    private float radio;

    public Circulo(float radio, String color, String nombre) {
        super(color, nombre);
        this.radio = radio;
    }

    public Circulo(float radio, String nombre) {
        super(nombre);
        this.radio = radio;
    }

    public float getRadio() {
        return radio;
    }

    public void setRadio(float radio) {
        this.radio = radio;
    }

    @Override
    public void setColor(String color) {
        if (color.equalsIgnoreCase("rojo") == true || color.equalsIgnoreCase("azul") == true) {
            super.setColor(color);
        }
    }

    @Override
    public String toString() {
        return super.toString() + "\nRadio : " + this.radio;
    }

    @Override
    public boolean equals(Object obj) {        
        if (obj instanceof Circulo == true) {
            Circulo otro = (Circulo) obj;
            return super.equals(obj) && this.radio == otro.radio;
        }
        return false;
    }
    
    public boolean equals(Circulo c){        
        return super.equals(c) && this.radio == c.radio;
    }

}
