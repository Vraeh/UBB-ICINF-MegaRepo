/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class MainSobreescritura {
    public static void main(String[] args) {
        Circulo c;
        c = new Circulo( 4.5f, "azul", "redondo");
        /* Una alternativa a la línea anterior es:
            c = new Circulo( (float) 4.5, "azul", "redondo");
        */
        
        /* Imprimir el objeto */
        //System.out.println("Objeto círculo : " + c.toString());
        System.out.println("Objeto círculo : " + c);
        
        /* Creamos un triángulo */
        Triangulo t = new Triangulo(6, 3.5f, "rojo", "mi triangulo");
        System.out.println("Triangulo : " + t);
        
        Figura fx = new Circulo(5.6f, "rojo", "gordito");
        
        System.out.println("? : " + fx);
        
        ArrayList<Figura> lst = new ArrayList();
    }
}
