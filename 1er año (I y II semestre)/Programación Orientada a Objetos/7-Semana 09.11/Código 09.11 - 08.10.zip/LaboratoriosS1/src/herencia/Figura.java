/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author Jazna
 */
public class Figura {
    private String color, nombre;

    public Figura(String color, String nombre) {
        this.setColor(color);
        this.nombre = nombre;
    }

    public Figura(String nombre) {
        this.nombre = nombre;
    }
    
    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    @Override
    public String toString(){
        return "\nNombre : " + this.nombre + "\nColor : " + this.color;
    }

    @Override
    public boolean equals(Object obj) {        
        /* Comprobar si se trata de una Figura */
        if (obj instanceof Figura == true){
       
            Figura otra = (Figura) obj;
            return ((this.color.equalsIgnoreCase(otra.color) == true) &&
                    (this.nombre.equalsIgnoreCase(otra.nombre) == true));
        }
        return false;
    }
    
    public boolean equals(Figura f){       
        return this.color.equalsIgnoreCase(f.color) &&
                this.nombre.equalsIgnoreCase(f.nombre);
    }
    
    
}
