/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author Jazna
 */
public class MainUsandoEquals {
    public static void main(String[] args) {
        Circulo cx, cy;
        cx = new Circulo(2.3f, "rojo", "circulo");
        cy = new Circulo(2.3f, "rojo", "circulo");
        
        //System.out.println("Son iguales? : " + cx.equals(cy));
        
        /* Vamos a analizar las llamadas a equals */
        Figura fx = new Figura("rojo", "circulo");
        
        //System.out.println("Mi experimento : " + cy.equals(fx));
        //System.out.println("Otro experimento : " + cy.equals("soy un string"));
        
        //System.out.println("Otro experimento más : " + fx.equals(cx));
        
        Figura cz = new Circulo(2.5f, "azul", "redondo");
        System.out.println("Experimento final : " + cx.equals(cz));        
    }
}
