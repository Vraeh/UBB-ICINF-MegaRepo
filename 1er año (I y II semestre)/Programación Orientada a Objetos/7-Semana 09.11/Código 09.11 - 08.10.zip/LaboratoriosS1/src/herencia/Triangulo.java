/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package herencia;

/**
 *
 * @author Jazna
 */
public class Triangulo extends Figura{
    private float base, altura;

    public Triangulo(float base, float altura, String color, String nombre) {
        super(color, nombre);
        this.base = base;
        this.altura = altura;
    }

    public Triangulo(float base, float altura, String nombre) {
        super(nombre);
        this.base = base;
        this.altura = altura;
    }

    public float getBase() {
        return base;
    }

    public void setBase(float base) {
        this.base = base;
    }

    public float getAltura() {
        return altura;
    }

    public void setAltura(float altura) {
        this.altura = altura;
    }

    @Override
    public void setColor(String color) {
        if (color.equalsIgnoreCase("blanco") == true || color.equalsIgnoreCase("negro") == true){
            super.setColor(color); 
        }        
    }
    
    @Override
    public String toString(){
        return super.toString() + "\n Base : " + this.base + "\nAltura : " + this.altura;
    }
    
}
