/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package laboratorioss1;

/**
 *
 * @author Jazna
 */
public class Colaborador {

    /* Definiciòn de atributos */
    private String rut;
    private String nombre;
    private int sueldo;

    /* Constructores */
    public Colaborador() {
    }

    public Colaborador(String rut, String nombre, int sueldo) {
        this.rut = rut;
        this.setNombre(nombre);
        this.setSueldo(sueldo);
    }

    /* Métodos */
    public String getRut() {
        return rut;
    }

    public void setRut(String rut) {
        this.rut = rut;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        /* Verifica la regla de negocio */
        if (nombre.length() >= 3) {
            this.nombre = nombre;
        }
    }

    public int getSueldo() {
        return this.sueldo;
    }

    public void setSueldo(int sueldo) {
        /* Implementando la regla de negocio */
        if (sueldo >= 320000) {
            this.sueldo = sueldo;
        }
    }

    public int calcularBono() {
        if (this.sueldo <= 500000) {
            return (int) (this.sueldo * 0.2);
        }
        return (int) (this.sueldo * 0.1);
    }

}
