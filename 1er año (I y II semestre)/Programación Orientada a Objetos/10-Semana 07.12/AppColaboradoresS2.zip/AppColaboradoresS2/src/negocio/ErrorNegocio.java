/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

/**
 *
 * @author Jazna
 */
public class ErrorNegocio extends Exception implements ICodificable{
    private final byte codigo;

    public ErrorNegocio(byte codigo, String message) {
        super(message);
        this.codigo = codigo;
    }

    public byte getCodigo() {
        return codigo;
    }
       
}
