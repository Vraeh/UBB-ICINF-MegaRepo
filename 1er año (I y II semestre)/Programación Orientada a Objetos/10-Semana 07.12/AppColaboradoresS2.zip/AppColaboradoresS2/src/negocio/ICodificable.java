/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

/**
 *
 * @author Jazna
 */
public interface ICodificable {
    public byte ERROR_CODIGO = 10;
    public byte ERROR_SUELDO = 20;
    public byte ERROR_NOMBRE = 30;
    
    public byte ERROR_COLABORADOR_REPETIDO = 40;
}
