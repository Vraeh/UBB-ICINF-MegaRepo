/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

/**
 *
 * @author Jazna
 */
public class Colaborador {

    private short codigo;
    private String nombre;
    private int sueldo;

    private static final int SUELDO_MINIMO = 350000;

    public Colaborador(short codigo, String nombre, int sueldo)
        throws ErrorNegocio{
        this.setCodigo(codigo);
        this.setNombre(nombre);
        this.setSueldo(sueldo);
    }

    public short getCodigo() {
        return codigo;
    }

    public void setCodigo(short codigo) throws ErrorNegocio{
        if (codigo > 0) {
            this.codigo = codigo;
        }
        else{
            throw new ErrorNegocio(ErrorNegocio.ERROR_CODIGO, 
                    "Error en código. Debe ser positivo");
        }
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ErrorNegocio{
        if (nombre.length() >= 3){
            this.nombre = nombre;
        }
        else{
            throw new ErrorNegocio(ErrorNegocio.ERROR_NOMBRE, 
            "El nombre DEBE contener al menos 3 caracteres");
        }
    }

    public int getSueldo() {
        return sueldo;
    }

    public void setSueldo(int sueldo) throws ErrorNegocio{
        if (sueldo >= SUELDO_MINIMO){
            this.sueldo = sueldo;
        }
        else{
            throw new ErrorNegocio(ErrorNegocio.ERROR_SUELDO, 
            "Sueldo DEBE ser mayor o igual a " + SUELDO_MINIMO);
        }
    }

    @Override
    public boolean equals(Object o){
        return ((o instanceof Colaborador) && 
                ((Colaborador) o).codigo == this.codigo);
    }
}
