/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package negocio;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class ListaColaboradores {
    private ArrayList<Colaborador> colaboradores = new ArrayList();
    
    /* Agrega un colaborador a la colección, validando
    que no esté repetido */
    public void agregarColaborador(Colaborador nuevo) throws ErrorNegocio{
        /* Verificar que no exista */
        if (this.colaboradores.contains(nuevo) == true){
            throw new ErrorNegocio(ErrorNegocio.ERROR_COLABORADOR_REPETIDO, 
                    "Colaborador registrado previamente");
        }
        else{
            this.colaboradores.add(nuevo);
        }
    }

    public ArrayList<Colaborador> getColaboradores() {
        return colaboradores;
    }
    
    public int getTotalColaboradores(){
        return this.colaboradores.size();
    }
    
    public int calcularPromedioSueldo() throws ArithmeticException{
        int suma = 0;
        for(Colaborador c : this.colaboradores){
            suma += c.getSueldo();
        }
        return suma/this.colaboradores.size();
    }
    
    public ArrayList<Colaborador> colaboradoresSueldoMayorPromedio(){
        ArrayList<Colaborador> seleccionados = new ArrayList();
        int promedio = this.calcularPromedioSueldo();
        for(Colaborador c : this.colaboradores){
            if (c.getSueldo() > promedio){
                seleccionados.add(c);
            }
        }
        return seleccionados;
    }
}
