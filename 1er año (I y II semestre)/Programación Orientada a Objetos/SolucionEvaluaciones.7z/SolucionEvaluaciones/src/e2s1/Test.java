/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

/**
 *
 * @author Jazna
 */
public class Test {
    public static void main(String[] args) {
        int codigo = 200520;        
        String codigo1;
        codigo1 = codigo + "";
        String inicio = codigo1.substring(0);
        System.out.println(inicio);
        System.out.println("Tu comparación : " + inicio.equals("200"));
    }
}
