/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class Usuario {
    private String nombre;
    private final ArrayList<ElementoCalificable> calificaciones = new ArrayList<>();

    public Usuario(String nombre) {
        this.nombre = nombre;
    }
   
    public void agregarElemento(ElementoCalificable e){
        this.calificaciones.add(e);
    }

    public String getNombre() {
        return nombre;
    }

    public ArrayList<ElementoCalificable> getCalificaciones() {
        return calificaciones;
    }

    @Override
    public String toString() {
        return "{" + this.nombre  + "} tiene " + this.calificaciones.size() + " series/peliculas calificadas";
    }
    
    public byte promedioEpisodiosSeries(){
        byte suma = 0; int total = 0;
        for(ElementoCalificable e : this.calificaciones){
            if (e instanceof Serie){
                suma += ((Serie) e).getTotalEpisodios();
                total +=1;
            }
        }
        return (total == 0?0: (byte) (suma/total));
    }
    
    public int totalPeliculasMasLikes(){
        short maximo = 0; int total = 0;
        for(ElementoCalificable e : this.calificaciones){
            if (maximo < e.getCantidadLikes()){
                maximo = e.getCantidadLikes();
            }
        }
        for(ElementoCalificable e : this.calificaciones){
            if (e instanceof Pelicula && e.getCantidadLikes() == maximo){
                total +=1;
            }
        }       
        return total;
    }
}
