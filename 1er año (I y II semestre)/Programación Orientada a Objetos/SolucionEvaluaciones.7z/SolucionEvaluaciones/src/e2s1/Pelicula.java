/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

/**
 *
 * @author Jazna
 */
public class Pelicula extends ElementoCalificable{
    private short duracionMinutos;

    public Pelicula(short duracionMinutos, int codigo) {
        super(codigo);
        this.duracionMinutos = duracionMinutos;
    }

    public Pelicula(String nombre, int codigo) {
        super(nombre, codigo);
    }

    public short getDuracionMinutos() {
        return duracionMinutos;
    }

    public void setDuracionMinutos(short duracionMinutos) {
        this.duracionMinutos = duracionMinutos;
    }

    @Override
    public String toString() {
        return  super.toString() + " con [" + this.duracionMinutos + "] minutos de duración";
    }

    @Override
    public void setCodigo(int codigo) {
        if(String.valueOf(codigo).endsWith("200")){
            super.setCodigo(codigo);
        }
    }
    
    public boolean equals(Pelicula p){
        return super.equals(p) && p.duracionMinutos == this.duracionMinutos;
    }
    
}
