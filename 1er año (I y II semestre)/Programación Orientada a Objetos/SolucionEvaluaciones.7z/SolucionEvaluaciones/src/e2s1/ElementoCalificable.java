/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

/**
 *
 * @author Jazna
 */
public class ElementoCalificable {
    private String nombre;
    private int codigo;
    private short cantidadLikes;

    public ElementoCalificable(String nombre, int codigo) {
        this.nombre = nombre;
        this.setCodigo(codigo);
    }

    public ElementoCalificable(int codigo) {
        this.setCodigo(codigo);
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    public int getCodigo() {
        return codigo;
    }

    public short getCantidadLikes() {
        return cantidadLikes;
    }

    public void agregarLikes(short nuevosLikes){
        this.cantidadLikes += nuevosLikes;
    }

    public void setCodigo(int codigo) {
        this.codigo = codigo;
    }

    @Override
    public String toString() {
        return this.nombre + " tiene [" + this.cantidadLikes + "] likes"; 
    }
    
    public boolean equals(ElementoCalificable e){
        return this.codigo == e.codigo;
    }

}
