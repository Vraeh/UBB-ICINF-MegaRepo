/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

/**
 *
 * @author Jazna
 */
public class Main {
    public static void main(String[] args) {
        Usuario u = new Usuario("Jazna");
        Pelicula px = new Pelicula((short)120, 156200);
        px.setNombre("Avengers. End game");
        Serie sx = new Serie((byte)16, "Salvation Temporada 1", 200400);
        Pelicula py = new Pelicula((short)150, 157200);
        Serie sy = new Serie((byte)12, "Salvation Temporada 2", 201400);
        
        u.agregarElemento(py);
        u.agregarElemento(px);
        u.agregarElemento(sx);
        u.agregarElemento(sy);
        
        sx.agregarLikes((short)100);
        px.agregarLikes((short)850);
        py.agregarLikes((short)820);
        
        System.out.println(u);
        System.out.println(px);
        System.out.println(sx);
        
        System.out.println("Promedio de cantidad de episodios : " + u.promedioEpisodiosSeries());
        System.out.println("Total de películas con más likes : " + u.totalPeliculasMasLikes());
    }
}
