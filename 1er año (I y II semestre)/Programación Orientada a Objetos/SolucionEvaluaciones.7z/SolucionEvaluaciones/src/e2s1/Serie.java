/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2s1;

/**
 *
 * @author Jazna
 */
public class Serie extends ElementoCalificable {

    private byte totalEpisodios;

    public Serie(int codigo) {
        super(codigo);
    }

    public Serie(byte totalEpisodios, String nombre, int codigo) {
        super(nombre, codigo);
        this.totalEpisodios = totalEpisodios;
    }

    public byte getTotalEpisodios() {
        return totalEpisodios;
    }

    public void setTotalEpisodios(byte totalEpisodios) {
        this.totalEpisodios = totalEpisodios;
    }

    @Override
    public String toString() {
        return super.toString() + " con [" + this.totalEpisodios + "] episodios";
    }

    public boolean equals(Serie p) {
        return super.equals(p) && this.totalEpisodios == p.totalEpisodios;
    }

    @Override
    public void setCodigo(int codigo) {
        if (String.valueOf(codigo).endsWith("300")) {
            super.setCodigo(codigo);
        }
    }
}
