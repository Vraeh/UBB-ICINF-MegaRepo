/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E3.negocio;

/**
 *
 * @author Jazna
 */
public class ErrorNegocio extends Exception{

    private final byte codigo;

    public byte getCodigo() {
        return codigo;
    }

    public ErrorNegocio(byte codigo, String mensaje) {
        super(mensaje);
        this.codigo = codigo;
    }
}
