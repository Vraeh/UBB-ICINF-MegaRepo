/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E3.negocio;

/**
 *
 * @author Jazna
 */
public final class Serie {

    private final String codigo;
    private String nombre;
    private byte temporada;
    private byte totalEpisodios;
    private byte episodiosVistos;

    public Serie(String nombre, byte temporada, byte totalEpisodios, byte episodiosVistos) throws ErrorNegocio {
        this.codigo = nombre.toUpperCase() + " T." + temporada;
        this.setTemporada(temporada);
        this.setNombre(nombre);
        this.setTotalEpisodios(totalEpisodios);
        this.setEpisodiosVistos(episodiosVistos);
    }

    public String getCodigo() {
        return codigo;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) throws ErrorNegocio {
        if (nombre.length() >= 2) {
            this.nombre = nombre;
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_NOMBRE, ICodificable.MSG_ERROR_NOMBRE);
        }
    }

    public byte getTemporada() {
        return temporada;
    }

    public byte getTotalEpisodios() {
        return totalEpisodios;
    }

    public byte getEpisodiosVistos() {
        return episodiosVistos;
    }

    public void setEpisodiosVistos(byte episodiosVistos) throws ErrorNegocio {
        if (episodiosVistos >= 0 && episodiosVistos <= this.totalEpisodios) {
            this.episodiosVistos += episodiosVistos;
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_VISTOS, ICodificable.MSG_ERROR_VISTOS);
        }
    }

    public void setTemporada(byte temporada) throws ErrorNegocio {
        if (temporada > 0) {
            this.temporada = temporada;
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_TEMPORADA, ICodificable.MSG_ERROR_TEMPORADA);
        }
    }

    public void setTotalEpisodios(byte totalEpisodios) throws ErrorNegocio {
        if (totalEpisodios > 0) {
            this.totalEpisodios = totalEpisodios;
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_EPISODIOS, ICodificable.MSG_ERROR_EPISODIOS);
        }
    }

    @Override
    public boolean equals(Object s) {
        return s instanceof Serie && this.codigo.equalsIgnoreCase(((Serie) s).codigo);
    }
}
