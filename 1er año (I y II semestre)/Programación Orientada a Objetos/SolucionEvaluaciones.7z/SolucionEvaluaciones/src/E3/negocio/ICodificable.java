/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E3.negocio;

/**
 *
 * @author Jazna
 */
public interface ICodificable {
    byte CODE_ERROR_NOMBRE = 10;
    byte CODE_ERROR_TEMPORADA = 11;
    byte CODE_ERROR_SERIE_REPETIDA = 12;
    byte CODE_ERROR_EPISODIOS = 13;
    byte CODE_ERROR_VISTOS = 14;
    
    String MSG_ERROR_EPISODIOS = "Error de total de episodios";
    String MSG_ERROR_NOMBRE = "Nombre debe tener al menos 5 caracteres";
    String MSG_ERROR_TEMPORADA = "Número de temporada DEBE ser mayor o igual a 1";
    String MSG_ERROR_VISTOS = "Cantidad de episodios vistos DEBE ser menor al total de episodios";
    
    String MSG_ERROR_SERIE_REPETIDA = "Serie previamente registrada";
}
