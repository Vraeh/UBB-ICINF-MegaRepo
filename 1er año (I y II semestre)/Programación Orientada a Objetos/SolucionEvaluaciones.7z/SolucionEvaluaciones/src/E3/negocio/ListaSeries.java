/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E3.negocio;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class ListaSeries {
    private ArrayList<Serie> series = new ArrayList();
    
    public void agregarSerie(Serie s) throws ErrorNegocio{
        if (!this.series.contains(s)){
            this.series.add(s);
        }
        else{
            throw new ErrorNegocio(ICodificable.CODE_ERROR_SERIE_REPETIDA, ICodificable.MSG_ERROR_SERIE_REPETIDA);
        }
    }

    public ArrayList<Serie> getSeries() {
        return series;
    }
}
