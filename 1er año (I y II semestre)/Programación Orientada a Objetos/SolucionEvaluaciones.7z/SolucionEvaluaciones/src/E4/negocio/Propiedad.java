/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E4.negocio;

/**
 *
 * @author Jazna
 */
public final class Propiedad {

    private String rol;
    private int precio;
    private String comuna;
    private boolean tieneEstacionamiento;

    public Propiedad(String rol) throws ErrorNegocio {
        this.setRol(rol);
    }
    
    public Propiedad(String rol, int precio, String comuna, boolean tieneEstacionamiento) throws ErrorNegocio {
        this.setPrecio(precio);
        this.setRol(rol);
        this.comuna = comuna;
        this.tieneEstacionamiento = tieneEstacionamiento;
    }

    public int getPrecio() {
        return precio;
    }

    public void setPrecio(int precio) throws ErrorNegocio {
        if (precio > 0) {
            this.precio = precio;
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_PRECIO, ICodificable.MSG_ERROR_PRECIO);
        }
    }

    public String getComuna() {
        return comuna;
    }

    public void setComuna(String comuna) {
        this.comuna = comuna;
    }

    public boolean isTieneEstacionamiento() {
        return tieneEstacionamiento;
    }

    public void setTieneEstacionamiento(boolean tieneEstacionamiento) {
        this.tieneEstacionamiento = tieneEstacionamiento;
    }

    public String getRol() {
        return rol;
    }

    public void setRol(String rol) throws ErrorNegocio {
        if (rol.length() == 6 && rol.charAt(3) == '-') {
            int anterior = Integer.valueOf(rol.substring(0, 3));
            int posterior = Integer.valueOf(rol.substring(4));
            if ((anterior >= 100 && anterior < 400) && (posterior >= 10 && posterior < 30)) {
                this.rol = rol;
            } else {
                throw new ErrorNegocio(ICodificable.CODE_ERROR_ROL, ICodificable.MSG_ERROR_ROL);
            }
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_ROL, ICodificable.MSG_ERROR_ROL);
        }

    }

    @Override
    public boolean equals(Object o) {
        return (o instanceof Propiedad && ((Propiedad) o).rol.equals(this.rol));
    }
}
