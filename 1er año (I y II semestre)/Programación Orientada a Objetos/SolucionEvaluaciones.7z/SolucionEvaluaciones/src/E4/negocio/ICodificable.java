/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E4.negocio;

/**
 *
 * @author Jazna
 */
public interface ICodificable {
    byte CODE_ERROR_PRECIO = 10;
    byte CODE_ERROR_REPETIDA = 11;
    byte CODE_ERROR_ROL = 12;
    
    String MSG_ERROR_PRECIO = "Error al registrar precio. DEBE ser un valor positivo";
    String MSG_ERROR_PROPIEDAD_REPETIDA = "Propiedad previamente registrada";
    String MSG_ERROR_ROL = "El rol está formado por 3 dígitos un guión y otros 2 dígitos. Ejemplo 674-18";
}
