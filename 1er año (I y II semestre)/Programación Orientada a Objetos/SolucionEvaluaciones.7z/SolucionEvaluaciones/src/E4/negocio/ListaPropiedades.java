/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E4.negocio;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class ListaPropiedades {

    private final ArrayList<Propiedad> propiedades = new ArrayList();

    public void agregarPropiedad(Propiedad p) throws ErrorNegocio {
        if (!this.propiedades.contains(p)) {
            this.propiedades.add(p);
        } else {
            throw new ErrorNegocio(ICodificable.CODE_ERROR_REPETIDA, ICodificable.MSG_ERROR_PROPIEDAD_REPETIDA);
        }
    }

    public boolean eliminarTemporada(Propiedad p) {
        return this.propiedades.remove(p);
    }

    public int totalPropiedades() {
        return this.propiedades.size();
    }

    public ArrayList<Propiedad> getPropiedades() {
        return propiedades;
    }
}
