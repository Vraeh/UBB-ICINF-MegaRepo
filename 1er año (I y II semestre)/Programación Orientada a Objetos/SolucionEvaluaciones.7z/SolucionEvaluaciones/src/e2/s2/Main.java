/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2.s2;

/**
 *
 * @author Jazna
 */
public class Main {
    public static void main(String[] args) {
        Cliente c = new Cliente("Ciudadano kane");
        Corriente cc = new Corriente(1500000, 300123100);
        Ahorro ca = new Ahorro(0.07f, 200100250);
        Ahorro cb = new Ahorro(0.04f, 200900899);
        
        c.agregarCuenta(ca);
        c.agregarCuenta(cb);
        c.agregarCuenta(cc);
        
        cc.depositar(100000);
        ca.depositar(56000);
        cb.depositar(630000);
        
        System.out.println(cc);
        System.out.println(ca);
        System.out.println(cb);
        System.out.println(c);
        System.out.println("Monto en cuentas ahorro : " + c.montoTotalCuentasAhorro());
        System.out.println("Monto total en todas las cuentas : " + c.montoTotal());
    }
}
