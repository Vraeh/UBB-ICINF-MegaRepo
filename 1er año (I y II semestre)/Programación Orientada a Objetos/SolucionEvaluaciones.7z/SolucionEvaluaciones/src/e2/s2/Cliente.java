/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2.s2;

import java.util.ArrayList;

/**
 *
 * @author Jazna
 */
public class Cliente {
    private final ArrayList<Cuenta> cuentas = new ArrayList();
    private String nombre;

    public Cliente(String nombre) {
        this.nombre = nombre;
    }

    public ArrayList<Cuenta> getCuentas() {
        return cuentas;
    }

    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
    
    public int montoTotal(){
        int suma = 0;
        for(Cuenta c : this.cuentas){
            suma += c.getSaldo();
        }
        return suma;
    }
    
    public int montoTotalCuentasAhorro(){
        int suma = 0;
        for(Cuenta c : this.cuentas){
            if (c instanceof Ahorro){
                suma += c.getSaldo();    
            }
        }
        return suma;
    }
    
    public void agregarCuenta(Cuenta nueva){
        this.cuentas.add(nueva);
    }

    @Override
    public String toString() {
        return "Cliente {" +  this.nombre + " tiene {" + this.cuentas.size() + "} cuentas";
    }
    
    
}
