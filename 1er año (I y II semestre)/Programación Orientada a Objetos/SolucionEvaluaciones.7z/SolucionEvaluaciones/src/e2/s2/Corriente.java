/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2.s2;

/**
 *
 * @author Jazna
 */
public class Corriente extends Cuenta{
    private int lineaSobregiro;
    private int retenciones;

    public Corriente(int lineaSobregiro, int retenciones, int numero) {
        super(numero);
        this.lineaSobregiro = lineaSobregiro;
        this.retenciones = retenciones;
    }

    public Corriente(int lineaSobregiro, int numero) {
        super(numero);
        this.lineaSobregiro = lineaSobregiro;
    }

    public int getLineaSobregiro() {
        return lineaSobregiro;
    }

    public void setLineaSobregiro(int lineaSobregiro) {
        this.lineaSobregiro = lineaSobregiro;
    }

    public int getRetenciones() {
        return retenciones;
    }

    public void setRetenciones(int retenciones) {
        this.retenciones = retenciones;
    }

    @Override
    public String toString() {
        return super.toString() + "; Retenciones : $["+ this.retenciones + "]"; 
    }

    public boolean equals(Corriente c) {
        return super.equals(c); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public void setNumero(int numero) {
        if (String.valueOf(numero).startsWith("300")){
            super.setNumero(numero);
        }
    }
}
