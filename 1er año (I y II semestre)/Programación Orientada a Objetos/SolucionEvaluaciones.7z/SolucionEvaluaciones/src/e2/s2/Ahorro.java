/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package e2.s2;

/**
 *
 * @author Jazna
 */
public class Ahorro extends Cuenta {

    private float tasaInteres;

    public Ahorro(float tasaInteres, int numero) {
        super(numero);
        this.tasaInteres = tasaInteres;
    }

    public Ahorro(float tasaInteres, int numero, byte yearApertura) {
        super(numero, yearApertura);
        this.tasaInteres = tasaInteres;
    }

    public float getTasaInteres() {
        return tasaInteres;
    }

    public void setTasaInteres(float tasaInteres) {
        this.tasaInteres = tasaInteres;
    }

    public boolean equals(Ahorro c) {
        return super.equals(c); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public String toString() {
        return super.toString() + " con tasa de interes de " + this.tasaInteres*100 + "%";
    }

    @Override
    public void setNumero(int numero) {
        if (String.valueOf(numero).startsWith("200")){
            super.setNumero(numero);
        }
    }
    
    
}
